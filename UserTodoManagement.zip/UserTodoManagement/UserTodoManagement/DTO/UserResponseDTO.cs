﻿namespace UserTodoManagement.DTO
{
    public class UserResponseDTO
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public List<TodoItemResponseDTO> TodoItems { get; set; } = new List<TodoItemResponseDTO>();
    }
}
