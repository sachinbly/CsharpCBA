﻿using System.ComponentModel.DataAnnotations;

namespace UserTodoManagement.DTO
{
    public class UserDTO
    {
        [Required]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}