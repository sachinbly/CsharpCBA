﻿using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserTodoManagement.Data;
using UserTodoManagement.DTO;
using UserTodoManagement.Models;

namespace UserTodoManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult CreateUser(UserDTO userDto)
        {
            var user = new User { Username = userDto.Username, Email = userDto.Email };
            _context.Users.Add(user);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUserById), new { id = user.UserNo }, user);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(UserResponseDTO), 200)]
        public IActionResult GetUserById(int id)
        {
            var user = _context.Users.Include(u => u.TodoItems).FirstOrDefault(u => u.UserNo == id);
            if (user == null) return NotFound();

            var userResponse = new UserResponseDTO
            {
                Id = user.UserNo,
                Username = user.Username,
                Email = user.Email,
                TodoItems = user.TodoItems.Select(todoItem => new TodoItemResponseDTO
                {
                    ToDoId = todoItem.ToDoId,
                    Title = todoItem.Title,
                    Description = todoItem.Description
                }).ToList()
            };

            return Ok(userResponse);
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<UserResponseDTO>), 200)]
        public IActionResult GetAllUsers()
        {
            var users = _context.Users.Include(u => u.TodoItems).ToList();
            var userResponses = users.Select(user => new UserResponseDTO
            {
                Id = user.UserNo,
                Username = user.Username,
                Email = user.Email,
                TodoItems = user.TodoItems.Select(todoItem => new TodoItemResponseDTO
                {
                    ToDoId = todoItem.ToDoId,
                    Title = todoItem.Title,
                    Description = todoItem.Description
                }).ToList()
            });

            return Ok(userResponses);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, UserDTO userDto)
        {
            var user = _context.Users.Find(id);
            if (user == null) return NotFound();

            user.Username = userDto.Username;
            user.Email = userDto.Email;
            _context.Users.Update(user);
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null) return NotFound();
            _context.Users.Remove(user);
            _context.SaveChanges();
            return NoContent();
        }
    }
    public class UserResponseDTO
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public List<TodoItemResponseDTO> TodoItems { get; set; } // Add this line
    }
}
