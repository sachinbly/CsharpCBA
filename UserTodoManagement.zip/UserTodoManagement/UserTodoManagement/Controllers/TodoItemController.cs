﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserTodoManagement.Data;
using UserTodoManagement.DTO;
using UserTodoManagement.Models;

namespace UserTodoManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoItemController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TodoItemController(AppDbContext context)
        {
            _context = context;
        }

       
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult CreateTodoItem(TodoItemDTO todoItemDto, int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null)
            {
                return NotFound("User not found");
            }

            var todoItem = new TodoItem
            {
                Title = todoItemDto.Title,
                Description = todoItemDto.Description,
                IsCompleted = todoItemDto.IsCompleted,
                User = user // Associate the user with the todo item
            };

            _context.TodoItems.Add(todoItem);
            _context.SaveChanges();

            var responseDto = new TodoItemResponseDTO
            {
                ToDoId = todoItem.ToDoId,
                Title = todoItem.Title,
                Description = todoItem.Description                
            };

            return CreatedAtAction(nameof(GetTodoItemById), new { id = todoItem.ToDoId }, responseDto);
        }

        
        /// Gets a TodoItem by ID.
        
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetTodoItemById(int id)
        {
            var todoItem = _context.TodoItems.FirstOrDefault(t => t.ToDoId == id);
            if (todoItem == null) return NotFound();

            var responseDto = new TodoItemResponseDTO
            {
                ToDoId = todoItem.ToDoId,
                Title = todoItem.Title,
                Description = todoItem.Description
            };

            return Ok(responseDto);
        }

        
        /// Gets all TodoItems.
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult GetAllTodoItems()
        {
            var todoItems = _context.TodoItems.ToList();
            foreach (var todoItem in todoItems)
            {
                if (todoItem.User != null)
                {
                    todoItem.User = _context.Users.Find(todoItem.User.UserNo);
                }
            }

            var responseDtos = todoItems.Select(todoItem => new TodoItemResponseDTO
            {
                ToDoId = todoItem.ToDoId,
                Title = todoItem.Title,
                Description = todoItem.Description
            }).ToList();

            return Ok(responseDtos);
        }

        
        /// Updates a TodoItem.
        
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult UpdateTodoItem(int id, TodoItemDTO todoItemDto)
        {
            var todoItem = _context.TodoItems.Find(id);
            if (todoItem == null) return NotFound();

            todoItem.Title = todoItemDto.Title;
            todoItem.Description = todoItemDto.Description;
            todoItem.IsCompleted = todoItemDto.IsCompleted;
            _context.TodoItems.Update(todoItem);
            _context.SaveChanges();
            return NoContent();
        }

        
        /// Deletes a TodoItem.
        
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult DeleteTodoItem(int id)
        {
            var todoItem = _context.TodoItems.Find(id);
            if (todoItem == null) return NotFound();
            _context.TodoItems.Remove(todoItem);
            _context.SaveChanges();
            return NoContent();
        }


    }

    public class TodoItemResponseDTO
    {
        public int ToDoId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }

}