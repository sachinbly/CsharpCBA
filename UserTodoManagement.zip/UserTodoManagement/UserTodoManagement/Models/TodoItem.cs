﻿using System.ComponentModel.DataAnnotations;

namespace UserTodoManagement.Models
{
    public class TodoItem
    {
        [Key]
        public int ToDoId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }
        public User User { get; set; }
    }
}