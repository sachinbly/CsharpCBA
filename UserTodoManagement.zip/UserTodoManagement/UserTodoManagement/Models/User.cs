﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace UserTodoManagement.Models
{
    public class User
    {
        [Key]
        public int UserNo { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public List<TodoItem> TodoItems { get; set; } = new List<TodoItem>();
    }
}