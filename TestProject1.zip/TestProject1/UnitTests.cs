using NUnit.Framework;
using static RestAssured.Dsl;
using System;
using System.Collections.Generic;
using System.Net;
using UserTodoManagement.DTO;
using UserTodoManagement.Models;
using Namotion.Reflection;


namespace UserTodoManagement.Tests
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class UnitTests
    {
        private const string BaseUrl = "https://localhost:7171/api";

        [SetUp]
        public void SetUp()
        {
            // Ensure the necessary test data exists
            CreateTestUser();
            CreateTestTodoItem();
        }

        private void CreateTestUser()
        {
            var userDto = new UserDTO { Username = "testuser", Email = "testuser@example.com" };

            Given()
                .Body(userDto)
                .When()
                .Post($"{BaseUrl}/User")
                .Then()
                .StatusCode(HttpStatusCode.Created);
        }

        private void CreateTestTodoItem()
        {
            var todoItemDto = new TodoItemDTO { Title = "Test Todo", Description = "Test Description", IsCompleted = false };
            int userId = 1; // Assume this user exists

            Given()
                .Body(todoItemDto)
                .When()
                .Post($"{BaseUrl}/TodoItem?userId={userId}")
                .Then()
                .StatusCode(HttpStatusCode.Created);
        }

        [Test, Order(1)]
        public void NewUser_Success()
        {
            var userDto = new UserDTO { Username = "newuser", Email = "newuser@example.com" };

            Given()
                .Body(userDto)
                .When()
                .Post($"{BaseUrl}/User")
                .Then()
                .StatusCode(HttpStatusCode.Created);
        }

        [Test, Order(2)]
        public void NewUser_Error()
        {
            var userDto = new UserDTO { Username = "", Email = "" };

            Given()
                .Body(userDto)
                .When()
                .Post($"{BaseUrl}/User")
                .Then()
                .StatusCode(HttpStatusCode.BadRequest);
        }

        [Test, Order(3)]
        public void GetUserById_Success()
        {
            int userId = 1; // Assume this user exists

            Given()
                .When()
                .Get($"{BaseUrl}/User/{userId}")
                .Then()
                .StatusCode(HttpStatusCode.OK);
        }

        [Test, Order(4)]
        public void GetUserById_NotFound()
        {
            int userId = 99; // Assume this user does not exist

            Given()
                .When()
                .Get($"{BaseUrl}/User/{userId}")
                .Then()
                .StatusCode(HttpStatusCode.NotFound);
        }

        [Test, Order(5)]
        public void CreateTodoItem_Success()
        {
            var todoItemDto = new TodoItemDTO { Title = "New Test Todo", Description = "New Test Description", IsCompleted = false };
            int userId = 1; // Assume this user exists

            Given()
                .Body(todoItemDto)
                .When()
                .Post($"{BaseUrl}/TodoItem?userId={userId}")
                .Then()
                .StatusCode(HttpStatusCode.Created);
        }

        [Test, Order(6)]
        public void CreateTodoItem_UserNotFound()
        {
            var todoItemDto = new TodoItemDTO { Title = "Test Todo", Description = "Test Description", IsCompleted = false };
            int userId = 99; // Assume this user does not exist

            Given()
                .Body(todoItemDto)
                .When()
                .Post($"{BaseUrl}/TodoItem?userId={userId}")
                .Then()
                .StatusCode(HttpStatusCode.NotFound);
        }

        [Test, Order(7)]
        public void GetTodoItemById_Success()
        {
            int todoItemId = 1; // Assume this todo item exists

            Given()
                .When()
                .Get($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.OK);
        }

        [Test, Order(8)]
        public void GetTodoItemById_NotFound()
        {
            int todoItemId = 999; // Assume this todo item does not exist

            Given()
                .When()
                .Get($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.NotFound);
        }

        [Test, Order(9)]
        public void UpdateTodoItem_Success()
        {
            var todoItemDto = new TodoItemDTO { Title = "Updated Title", Description = "Updated Description", IsCompleted = true };
            int todoItemId = 1; // Assume this todo item exists

            Given()
                .Body(todoItemDto)
                .When()
                .Put($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.NoContent);
        }

        [Test, Order(10)]
        public void UpdateTodoItem_NotFound()
        {
            var todoItemDto = new TodoItemDTO { Title = "Updated Title", Description = "Updated Description", IsCompleted = true };
            int todoItemId = 989; // Assume this todo item does not exist

            Given()
                .Body(todoItemDto)
                .When()
                .Put($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.NotFound);
        }

        [Test, Order(11)]
        public void DeleteTodoItem_Success()
        {
            int todoItemId = 5; // Assume this todo item exists

            Given()
                .When()
                .Delete($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.NoContent);
        }

        [Test, Order(12)]
        public void DeleteTodoItem_NotFound()
        {
            int todoItemId = 799; // Assume this todo item does not exist

            Given()
                .When()
                .Delete($"{BaseUrl}/TodoItem/{todoItemId}")
                .Then()
                .StatusCode(HttpStatusCode.NotFound);
        }
    }


}
